// module-info.java
module com.jdojo.misc {
    requires java.desktop; 
            
    exports com.jdojo.misc;
}
