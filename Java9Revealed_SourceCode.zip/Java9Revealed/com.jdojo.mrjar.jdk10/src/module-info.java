// module-info.java
module com.jdojo.mrjar {
    exports com.jdojo.mrjar;
}

