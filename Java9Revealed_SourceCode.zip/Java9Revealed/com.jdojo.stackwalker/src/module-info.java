// module-info.java
module com.jdojo.stackwalker {
    exports com.jdojo.stackwalker;
}
