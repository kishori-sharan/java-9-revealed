// module-info.com version 2.0
module com.jdojo.layer {
    exports com.jdojo.layer;
}
