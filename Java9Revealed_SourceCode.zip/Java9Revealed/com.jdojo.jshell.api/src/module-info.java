// module-info.java
module com.jdojo.jshell.api {
    requires jdk.jshell;
}
