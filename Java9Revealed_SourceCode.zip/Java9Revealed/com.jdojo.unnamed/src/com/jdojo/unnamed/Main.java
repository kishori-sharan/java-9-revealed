// Main.java
package com.jdojo.unnamed;

import com.jdojo.reflect.Item;

public class Main {
    public static void main(String[] args) {
        int v = Item.v;
        System.out.println("Item.v = " + v);
    }
}
