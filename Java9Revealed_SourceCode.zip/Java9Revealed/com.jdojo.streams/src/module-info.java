// module-info.java
module com.jdojo.streams {
    exports com.jdojo.streams;
}
