// module-info.java
module com.jdojo.prime {        
    exports com.jdojo.prime;

    uses com.jdojo.prime.PrimeChecker;
}
