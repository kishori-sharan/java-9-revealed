// module-info.java
module com.jdojo.process.api {
    exports com.jdojo.process.api;
}
