// module-info.java

import com.jdojo.module.api.annotation.Version;
        
@Deprecated(since="1.2", forRemoval=false)
@SuppressWarnings("unchecked")
@Version(major=1, minor=2)
module com.jdojo.module.api.annotation {
    // No module statements
}
