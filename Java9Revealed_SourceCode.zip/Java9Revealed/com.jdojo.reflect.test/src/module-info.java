// module-info.java
module com.jdojo.reflect.test {    
    requires com.jdojo.reflect;
}