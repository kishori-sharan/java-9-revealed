// EncapsulatedTest.java
package com.jdojo.encapsulated;

public class EncapsulatedTest {     
}
