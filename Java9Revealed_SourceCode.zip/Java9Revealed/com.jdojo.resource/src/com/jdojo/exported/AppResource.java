// AppResource.java
package com.jdojo.exported;


public class AppResource {
    public static void main(String[] args) {
        
    }
}
