// OpenTest.java
package com.jdojo.opened;

public class OpenedTest {
   
}
