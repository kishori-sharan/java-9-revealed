// module-info.java
module com.jdojo.resource {    
    exports com.jdojo.exported;
    
    opens com.jdojo.opened;
}

