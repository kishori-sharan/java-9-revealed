// Address.java
package com.jdojo.contact.info;

public class Address {
    public static void main(String[] args) {
    }
}
