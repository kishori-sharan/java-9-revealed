// Phone.java
package com.jdojo.contact.info;

public class Phone {
    public static void main(String[] args) {
    }
}
