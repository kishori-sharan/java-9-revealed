// Validator.java
package com.jdojo.contact.validator;

public interface Validator {
    void isValid();
}
