// PhoneValidator.java
package com.jdojo.contact.validator;

public class PhoneValidator implements Validator {  
    @Override
    public void isValid() {
        throw new UnsupportedOperationException("Not supported yet."); 
    }
}
