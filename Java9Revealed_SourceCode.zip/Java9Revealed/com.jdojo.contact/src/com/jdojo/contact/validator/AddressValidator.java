// AddressValidator.java
package com.jdojo.contact.validator;

public class AddressValidator implements Validator {

    @Override
    public void isValid() {
        throw new UnsupportedOperationException("Not supported yet."); 
    }
    
}
