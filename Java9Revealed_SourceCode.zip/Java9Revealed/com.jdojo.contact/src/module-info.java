// module-info.java

module com.jdojo.contact {
}
