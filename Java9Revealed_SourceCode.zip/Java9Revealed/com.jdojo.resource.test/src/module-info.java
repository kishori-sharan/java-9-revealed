// module-info.java
module com.jdojo.resource.test {
    requires com.jdojo.resource;
    
    exports com.jdojo.resource.test;
}

