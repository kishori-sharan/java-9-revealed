// module-info.java
module com.jdojo.collection {
    exports com.jdojo.collection;
}
