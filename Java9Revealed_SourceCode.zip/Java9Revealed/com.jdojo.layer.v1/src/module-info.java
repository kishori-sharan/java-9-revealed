// module-info.com version 1.0
module com.jdojo.layer {
    exports com.jdojo.layer;
}
