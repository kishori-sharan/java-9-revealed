// module-info.java
module com.jdojo.person.test {
    requires com.jdojo.person;    
}
