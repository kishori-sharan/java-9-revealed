// module-info.java
module com.jdojo.resource.jrt {
    requires java.desktop;
}

