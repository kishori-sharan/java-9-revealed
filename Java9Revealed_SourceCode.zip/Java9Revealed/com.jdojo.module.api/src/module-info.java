// module-info.java
module com.jdojo.module.api {
    requires com.jdojo.prime;
    requires com.jdojo.intro;
    requires java.sql; 
    exports com.jdojo.module.api;    
}