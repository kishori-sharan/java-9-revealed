// module-info.java
module com.jdojo.prime.client {
    requires com.jdojo.prime;
}

