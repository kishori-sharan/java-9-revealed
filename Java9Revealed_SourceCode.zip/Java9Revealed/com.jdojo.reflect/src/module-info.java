// module-info.java
module com.jdojo.reflect {
    exports com.jdojo.reflect;
    
    opens com.jdojo.reflect;
}
