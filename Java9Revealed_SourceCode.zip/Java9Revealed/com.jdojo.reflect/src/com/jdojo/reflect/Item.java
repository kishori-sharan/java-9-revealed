// Item.java
package com.jdojo.reflect;

public class Item {
    static private int s = 10;
    static int t = 20;
    static protected int u = 30;
    static public int v = 40;
}
