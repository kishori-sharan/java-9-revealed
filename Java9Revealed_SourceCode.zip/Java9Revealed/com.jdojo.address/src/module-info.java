// module-info.java
module com.jdojo.address {
    // Export the com.jdojo.address package
    exports com.jdojo.address;
}
