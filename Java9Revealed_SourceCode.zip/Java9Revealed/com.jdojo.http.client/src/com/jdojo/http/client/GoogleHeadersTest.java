// GoogleHeadersTest.java
package com.jdojo.http.client;

import java.net.URI;
import jdk.incubator.http.HttpClient;
import jdk.incubator.http.HttpRequest;
import jdk.incubator.http.HttpResponse;
import static jdk.incubator.http.HttpResponse.BodyHandler.asString;


public class GoogleHeadersTest {
    public static void main(String[] args) throws Exception {

// Build the request
        HttpRequest request = HttpRequest.newBuilder()
                .uri(new URI("http://google.com"))
                .GET()
                .build();

// Send the request and get a Response
        HttpResponse<String> response = HttpClient.newHttpClient()
                .send(request, asString());

// Get the response body and print it
        String body = response.body();
        System.out.println(body);

    }
}
