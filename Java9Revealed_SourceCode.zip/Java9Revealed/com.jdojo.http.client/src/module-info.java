// module-info.java
module com.jdojo.http.client {
    requires jdk.incubator.httpclient;
}
