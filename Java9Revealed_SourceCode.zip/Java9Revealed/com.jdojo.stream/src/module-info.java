// module-info.java
module com.jdojo.stream {
    exports com.jdojo.stream;
}
