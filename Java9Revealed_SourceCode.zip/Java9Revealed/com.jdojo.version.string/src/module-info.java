// module-info.java
module com.jdojo.version.string {
    exports com.jdojo.version.string;
}

