module claim {
    requires policy;    
    exports com.jdojo.claim;    
    requires java.sql;    
}
