// module-info.java
module com.jdojo.layer.test {
    // This module reads version 1.0 of the com.jdojo.layer module
    requires com.jdojo.layer;
}
