// module-info.com
module com.jdojo.unnamed.test {
    // No module statements
}
