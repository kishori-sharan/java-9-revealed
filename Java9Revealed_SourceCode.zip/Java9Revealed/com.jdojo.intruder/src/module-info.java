// module-info.java
module com.jdojo.intruder {
    // No module statements
}

