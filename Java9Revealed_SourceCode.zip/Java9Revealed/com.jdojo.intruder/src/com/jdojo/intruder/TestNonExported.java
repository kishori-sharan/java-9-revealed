// TestNonExported.java
package com.jdojo.intruder;

import com.jdojo.intro.Welcome;

public class TestNonExported {
    public static void main(String[] args) {
        Welcome.main(new String[]{});        
    }    
}
