// module-info.java

module com.jdojo.deprecation {
}
